package Model;

public class AdminContractsMod {
	 public String Contracttype;
	 public String ContractID;
	 public String ContractManager;
	 public String Startdate;
	 public String Enddate;
	 public String ContractWorkers;
	 public String ContractBudjet;
}


