package Model;

public class EmployeeAddress {
 public String EmployeeID;
 public String Street;
 public String HouseNum;
 public Integer Pincode;
 public String City;
 public String State;
 public String Country;
 public String Phone;
 public String Email;
}
