package Model;

public class EmployeeInsurance {
	 
	public Integer employeeID;
	 public String socialSecurityNumber;
	 public String taxID;
	 public String healthInsuranceType;
	 public String healthInsuranceID;
	 public String healthInsuranceProvider;
	 
}
