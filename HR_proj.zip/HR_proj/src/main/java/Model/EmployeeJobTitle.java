package Model;

public class EmployeeJobTitle {
	 public String EmployeeID;
	 public String EmployeeStatus;
	 public String EmployeeSubStatus;
	 public String EmployeeTitle;
	 public String CurrentJobTitle;
	 public String WorkingStatus;
	 
	 public String[] strEmploymentStatus = new String[]{"Internal","External"};
	 public String[] strEmploymentSubStatus = new String[]{"Full time","Part time","Internship","Working student"};

}
