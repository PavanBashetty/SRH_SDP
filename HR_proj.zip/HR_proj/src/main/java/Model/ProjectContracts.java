package Model;

public class ProjectContracts {
	public String projectID;
	public String projectName;
	public Integer reportingTo;
	public Integer projectBudget;
	public String startDate;
	public String endDate;
	public String stakeholderId;
	public String stakeholdername;	

}
